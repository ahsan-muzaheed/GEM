1. Recompile from https://github.com/snap-stanford/snap and add node2vec to system path.
2. To grant executable permission, run: chmod +x ./c_exe/node2vec

